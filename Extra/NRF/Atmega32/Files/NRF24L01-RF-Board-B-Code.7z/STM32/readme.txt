=====================================
Programming Interface
======================================
��SWD JTAG


======================================
Example Overview
======================================
��NRF24L01 transmit/receive example


======================================
Hardware Connection
======================================
��Connect the NRF24L01 RF Board to the SPI1 interface


======================================
Code Configuration
======================================
��Configure the macro definition in the main.c
  to select transmitting or receiving
#define Send	1			//transmit 
#define Receive	0			//receive

======================================
Example Result
======================================
Transmitter: press buttons to send data

Receiver: receive data and display them on the LED

The LED status should keep changing in accordance with the button pressed, which indicates the communication has been successful.